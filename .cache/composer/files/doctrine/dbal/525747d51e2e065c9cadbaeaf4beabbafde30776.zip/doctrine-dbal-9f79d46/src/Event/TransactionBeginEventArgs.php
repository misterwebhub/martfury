<?php

declare(strict_types=1);

namespace Doctrine\DBAL\Event;

class TransactionBeginEventArgs extends TransactionEventArgs
{
}
