<?php

namespace Mollie\Api\Types;

class MandateStatus
{
    const STATUS_PENDING = "pending";
    const STATUS_VALID = "valid";
    const STATUS_INVALID = "invalid";
}
