# laravel-form-builder

#501 Refactor to use Arr class for deprecated array helpers
- array_get
- array_pull
- array_set
- array_forget

- str_is
- str_contains
